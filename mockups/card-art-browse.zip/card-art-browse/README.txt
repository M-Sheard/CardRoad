Card Road — 120 card faces
=========================

Open index.html in any browser (double-click it).

- Filter by tier or search a name / ID
- Click a card to enlarge; arrows to step through
- Paintings only hides the gilt frame
- named/ has files like C001-Earwig.webp for Finder browsing
